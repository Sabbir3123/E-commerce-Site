<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart - E-Commerce Site</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <header>
        <div class="container">
            <h1>E-Commerce Site</h1>
            <nav>
                <a href="index.php">Home</a>
                <a href="categories.php">Categories</a>
                <a href="cart.php">Cart</a>
                <a href="logout.php">Logout</a>
            </nav>
        </div>
    </header>

    <main>
        <h2>Your Cart</h2>
        <table>
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Product 1</td>
                    <td>$10.00</td>
                    <td>2</td>
                    <td>$20.00</td>
                </tr>
                <tr>
                    <td>Product 2</td>
                    <td>$15.00</td>
                    <td>1</td>
                    <td>$15.00</td>
                </tr>
            </tbody>
        </table>
        <button>Checkout</button>
    </main>
</body>
</html>
