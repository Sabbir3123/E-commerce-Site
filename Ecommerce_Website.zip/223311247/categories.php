<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Categories - E-Commerce Site</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <header>
        <div class="container">
            <h1>E-Commerce Site</h1>
            <nav>
                <a href="index.php">Home</a>
                <a href="categories.php">Categories</a>
                <a href="cart.php">Cart</a>
                <a href="logout.php">Logout</a>
            </nav>
        </div>
    </header>

    <main>
        <h2>Product Categories</h2>
        <ul class="categories">
            <li><a href="#">Electronics</a></li>
            <li><a href="#">Clothing</a></li>
            <li><a href="#">Home & Kitchen</a></li>
            <li><a href="#">Books</a></li>
        </ul>
    </main>
</body>
</html>
