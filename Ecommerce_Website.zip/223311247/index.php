<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - E-Commerce Site</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <header>
        <div class="container">
            <h1>E-Commerce Site</h1>
            <nav>
                <a href="index.php">Home</a>
                <a href="register.php">Register</a>
                <a href="categories.php">Categories</a>
                <a href="cart.php">Cart</a>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="logout.php">Logout</a>
                <?php else: ?>
                    <a href="login.php">Login</a>
                <?php endif; ?>
            </nav>
        </div>
    </header>

    <main>
        <h2>Welcome to Our Store!</h2>
        <div class="products">
            <div class="product">
                <img src="images/product1.jpg" alt="Product 1">
                <h3>Product 1</h3>
                <p>$10.00</p>
                <button>Add to Cart</button>
            </div>
            <div class="product">
                <img src="images/product2.jpg" alt="Product 2">
                <h3>Product 2</h3>
                <p>$15.00</p>
                <button>Add to Cart</button>
            </div>
            <div class="product">
                <img src="images/product3.jpg" alt="Product 3">
                <h3>Product 3</h3>
                <p>$20.00</p>
                <button>Add to Cart</button>
            </div>
        </div>
    </main>
</body>
</html>
